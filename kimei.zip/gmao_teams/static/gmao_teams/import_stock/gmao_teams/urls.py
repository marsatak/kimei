path('affecter-piece/<int:equipe_id>/<int:doleance_id>/', views.affecter_piece, name='affecter_piece'),
